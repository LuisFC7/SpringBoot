package com.springboot.webapp.springbootwebapp.models.dto;

public class ParamDto {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    
}
