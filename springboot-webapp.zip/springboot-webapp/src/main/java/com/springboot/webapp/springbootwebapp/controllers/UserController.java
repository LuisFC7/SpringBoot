package com.springboot.webapp.springbootwebapp.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.springboot.webapp.springbootwebapp.models.User;

import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class UserController {

    @GetMapping("/details")
    public String details(Model model){

        User user = new User("User", "UserLast");
        user.setEmail("emailName@email.com");
        model.addAttribute("title", "HelloWorld");
        model.addAttribute("user", user);
        return "details";
        
    }

    @GetMapping("/list")
    public String list(ModelMap model){
        model.addAttribute("title", "Users List");
        return "list";
    }

    
    //Model Attribute sirve para pasar datos de forma global a metoodos y vistas
    @ModelAttribute("users")
    public List<User> usersModel(){
        return Arrays.asList(
            new User ("One","OneL", "email1@email.com"),
            new User ("Two","TwoL", "email2@email.com"),
            new User ("Three","ThreeL", "email3@email.com")
        );

    }
    
}
