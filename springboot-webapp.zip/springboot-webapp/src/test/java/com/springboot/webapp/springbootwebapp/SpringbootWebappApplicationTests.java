package com.springboot.webapp.springbootwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
